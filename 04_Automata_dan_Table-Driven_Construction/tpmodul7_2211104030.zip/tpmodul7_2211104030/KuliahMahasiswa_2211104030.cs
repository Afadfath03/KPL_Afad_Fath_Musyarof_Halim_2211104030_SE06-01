﻿using System.Text.Json;


namespace tpmodul7_2211104030 {
    public class KuliahMahasiswa_2211104030 {
        public courses[] courses { get; set; }
        public long nim { get; set; }
        public string fakultas { get; set; }

        Program.FolderPath FolderPath = new Program.FolderPath();

        public void ReadJSON() {
            string folderPath =
                FolderPath.searchPreviousFolder("tpmodul7_2211104030");
            string filePath = 
                Path.Combine(folderPath, "tp7_2_2211104030.json");

            if(File.Exists(filePath)) {
                string json = File.ReadAllText(filePath);
                KuliahMahasiswa_2211104030? data = JsonSerializer
                    .Deserialize<KuliahMahasiswa_2211104030>(json);

                if(data != null) {
                    int i = 1;
                    foreach(var course in data.courses) {
                        Console.WriteLine($"MK {i} {course.code}" +
                                          $" - " +
                                          $"{course.name}");
                        i++;
                    }
                }

                } else {
                Console.WriteLine("File tidak ditemukan");
            }
        }
    }

    public class courses {
        public string code { get; set; }
        public string name { get; set; }
    }
}