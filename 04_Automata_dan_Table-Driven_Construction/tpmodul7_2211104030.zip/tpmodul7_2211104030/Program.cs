﻿
namespace tpmodul7_2211104030 {
    class Program {
        static void Main(string[] args) {
            Console.WriteLine("Data Mahasiswa: ");
            DataMahasiswa_2211104030 dataMahasiswa = new DataMahasiswa_2211104030();
            dataMahasiswa.ReadJSON();

            Console.WriteLine("\n===============================\n");
            Console.WriteLine("Mata Kuliah: ");
            KuliahMahasiswa_2211104030 kuliahMahasiswa = new KuliahMahasiswa_2211104030();
            kuliahMahasiswa.ReadJSON();
        }

        public class FolderPath {
            public string searchPreviousFolder(string target) {
                string currentDirectory = Directory.GetCurrentDirectory();
                string targetFolderName = target;

                DirectoryInfo currentDirInfo = new DirectoryInfo(currentDirectory);

                while(currentDirInfo != null) {
                    if(currentDirInfo.Name.Equals(targetFolderName,
                        StringComparison.OrdinalIgnoreCase)) {
                        break;
                    }

                    currentDirInfo = currentDirInfo.Parent;
                }

                return currentDirInfo.FullName;
            }
        }
    }
}