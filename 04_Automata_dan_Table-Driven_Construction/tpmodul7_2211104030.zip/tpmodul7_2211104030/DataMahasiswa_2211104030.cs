﻿using System.Text.Json;


namespace tpmodul7_2211104030 {
    public class DataMahasiswa_2211104030 {
        public Nama nama { get; set; }
        public long nim { get; set; }
        public string fakultas { get; set; }

        Program.FolderPath FolderPath = new Program.FolderPath();

        public void ReadJSON() {
            string folderPath = 
                FolderPath.searchPreviousFolder("tpmodul7_2211104030");
            string filePath = 
                Path.Combine(folderPath, "tp7_1_2211104030.json");

            if(File.Exists(filePath)) {
                string json = File.ReadAllText(filePath);
                DataMahasiswa_2211104030? data = JsonSerializer
                    .Deserialize<DataMahasiswa_2211104030>(json);

                if(data != null) {
                    Console.WriteLine($"Nama {data.nama.depan} " +
                                      $"{data.nama.belakang} " +
                                      $"dengan nim {data.nim} " +
                                      $"dari fakultas {data.fakultas}");
                } else {
                    Console.WriteLine("Gagal deserialisation");
                }

            } else {
                Console.WriteLine("File tidak ditemukan");
            }
        }
    }

    public class Nama {
        public string depan { get; set; }
        public string belakang { get; set; }
    }
}