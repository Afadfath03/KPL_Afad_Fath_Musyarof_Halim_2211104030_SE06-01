﻿// A

Console.Write("masukkan nama anda: ");
string nama = Console.ReadLine();
Console.WriteLine("Selamat datang, " + nama + "!");


// B

int[] ints = new int[50];
for(int i = 0; i < 50; i++) {
    ints[i] = i;
}

foreach(int i in ints) {
    if(i % 3 == 0 && i % 2 == 0) {
        Console.WriteLine(i + " #$#$");
    } else if(i % 2 == 0) {
        Console.WriteLine(i + " ##");
    } else if(i % 3 == 0) {
        Console.WriteLine(i + " $$");
    } else {
        Console.WriteLine(i);
    }
}


// C

Console.Write("masukkan angka (1-10000): ");
int angka = Convert.ToInt32(Console.ReadLine());

bool isPrima = true;

if (angka == 0 | angka == 1) {
    isPrima = false;
} else {
    for(int i = 2; i < angka; i++) {
        if(angka % i == 0) {
            isPrima = false;
            break;
        }
    }
}

if(isPrima) {
    Console.WriteLine(angka + " adalah bilangan prima");
} else {
    Console.WriteLine(angka + " bukan bilangan prima");
}